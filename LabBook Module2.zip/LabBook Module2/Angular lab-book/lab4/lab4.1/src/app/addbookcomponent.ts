import { Component,Input,Output,EventEmitter,OnInit} from '@angular/core';
import {BookService} from './app.bookservice';

@Component({
    selector:'add-comp',
    templateUrl:'addbook.html'
})
export class AddBookComponent implements OnInit{

    constructor(private service:BookService){}
    bookall:any[]=[];
    ngOnInit(){
        this.service.getAllBooks().subscribe((data:any)=>this.bookall=data);
    }
    empDelete(data:number):any{
        this.bookall.splice(data,1);
    }
}