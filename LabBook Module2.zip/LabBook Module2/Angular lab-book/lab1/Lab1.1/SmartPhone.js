"use strict";
exports.__esModule = true;
var Smart = /** @class */ (function () {
    function Smart() {
    }
    Smart.printType = function () {
        return "SmartPhone";
    };
    return Smart;
}());
exports.Smart = Smart;
