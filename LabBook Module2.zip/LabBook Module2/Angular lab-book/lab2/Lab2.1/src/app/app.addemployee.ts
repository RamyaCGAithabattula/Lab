import {Component} from '@angular/core';

@Component({
    selector:'add-emp',
    templateUrl:'app.add.html'
})
export class AddEmployeeComponent{

   empId:number;
   empName:string;
   empSalary:number;
   empId2:number;
   empId3:number;
   empSalary2:number;
   empName2:number;
   empDepartment:any;
   empDepartment2:any;

   empall:any[]=[
    {empId: 1, empName: 'abcd',empSalary:1000,empDepartment:"Java"},
    {empId: 2, empName: 'ab',empSalary:2000,empDepartment:"JavaScript"},
    {empId: 3, empName: 'cd',empSalary:3000,empDepartment:".Net"},
    {empId: 4, empName: 'ad',empSalary:4000,empDepartment:"Pega"},
   ];
   addEmployee():any{

       this.empall.push({empId:this.empId,empName:this.empName,empSalary:this.empSalary,empDepartment:this.empDepartment})
       console.log("Employee Added...."+this.empId+" "+this.empName+this.empSalary);
   }
   

   deleteEmployee(data:number):any{
       this.empall.splice(data,1);
      
   }
   updateEmployee(data:number):any{
       for(let data of this.empall){
           if(data.empd==this.empId3){
             data.empId=this.empId2;
             data.empName=this.empName2;
             data.empSalary=this.empSalary2;
             data.empDepartment=this.empDepartment2;
             alert("Row Updated");
           }
       }
   }
    updateEmployee2(data:number):any{
        this.empId2=this.empall[data].empId;
        this.empName2=this.empall[data].empName;
        this.empSalary2=this.empall[data].empSalary;
        this.empDepartment2=this.empall[data].empDepartment;
    }
}
